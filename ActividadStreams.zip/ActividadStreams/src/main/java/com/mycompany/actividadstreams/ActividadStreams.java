/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.actividadstreams;
import java.util.*;
import java.util.stream.Collectors;
/**
 *
 * @author SamuelUribeSuarez
 */
public class ActividadStreams {

    public static void main(String[] args) {

        List<Estudiante> estudiantes = Arrays.asList(
                new Estudiante("Daniel", "Ingenieria", 4.8),
                new Estudiante("Luis", "Sistemas", 3.2),
                new Estudiante("Nicolas", "Ingenieria", 4.5),
                new Estudiante("Juan Diego", "Derecho", 2.9),
                new Estudiante("Samuel", "Sistemas", 4.9),
                new Estudiante("Felipe", "Derecho", 3.8),
                new Estudiante("David", "Ingenieria", 4.1),
                new Estudiante("Jose", "Sistemas", 2.5),
                new Estudiante("Juan Pablo", "Derecho", 4.3),
                new Estudiante("Andres", "Ingenieria", 3.6)
        );

        // Filtrar estudiantes aprobados
        System.out.println("=== APROBADOS ===");
        List<Estudiante> aprobados = estudiantes.stream()
                .filter(e -> e.getNota() >= 3.0)
                .collect(Collectors.toList());

        aprobados.forEach(System.out::println);

        // Ordenar por nota descendente y luego por nombre
        System.out.println("\n=== ORDENADOS ===");
        List<Estudiante> ordenados = estudiantes.stream()
                .sorted(Comparator.comparing(Estudiante::getNota)
                        .reversed()
                        .thenComparing(Estudiante::getNombre))
                .collect(Collectors.toList());

        ordenados.forEach(System.out::println);

        // Obtener los tres mejores
        System.out.println("\n=== TOP 3 ===");
        List<Estudiante> top3 = estudiantes.stream()
                .sorted(Comparator.comparing(Estudiante::getNota)
                        .reversed())
                .limit(3)
                .collect(Collectors.toList());

        top3.forEach(System.out::println);

        // Calcular promedio general
        double promedioGeneral = estudiantes.stream()
                .mapToDouble(Estudiante::getNota)
                .average()
                .orElse(0);

        System.out.println("\nPromedio General: " + promedioGeneral);

        // Agrupar por programa y calcular promedio
        System.out.println("\n=== PROMEDIO POR PROGRAMA ===");
        Map<String, Double> promedioPrograma = estudiantes.stream()
                .collect(Collectors.groupingBy(
                        Estudiante::getPrograma,
                        Collectors.averagingDouble(Estudiante::getNota)
                ));

        promedioPrograma.forEach((programa, promedio) ->
                System.out.println(programa + ": " + promedio));

        // Particionar aprobados y reprobados
        System.out.println("\n=== PARTICION ===");
        Map<Boolean, List<Estudiante>> particion = estudiantes.stream()
                .collect(Collectors.partitioningBy(
                        e -> e.getNota() >= 3.0
                ));

        System.out.println("Aprobados:");
        particion.get(true).forEach(System.out::println);

        System.out.println("\nReprobados:");
        particion.get(false).forEach(System.out::println);
    }
}

class Estudiante {
    private String nombre;
    private String programa;
    private double nota;

    public Estudiante(String nombre, String programa, double nota) {
        this.nombre = nombre;
        this.programa = programa;
        this.nota = nota;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPrograma() {
        return programa;
    }

    public double getNota() {
        return nota;
    }

    @Override
    public String toString() {
        return nombre + " - " + programa + " - " + nota;
    }
}